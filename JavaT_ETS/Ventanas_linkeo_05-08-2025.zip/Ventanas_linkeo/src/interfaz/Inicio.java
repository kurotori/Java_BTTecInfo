package interfaz;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Inicio extends JFrame {

    JTextField txtfDato;
    JButton btnEnviar;

    Inicio estaVentana; /// <----

    public Inicio() {
        configurar();
        estaVentana = this; /// <----
    }

    private void configurar() {
        setSize(640, 480);
        setPreferredSize(getSize());
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        txtfDato = new JTextField();
        txtfDato.setBounds(10, 10, 200, 30);
        getContentPane().add(txtfDato);

        btnEnviar = new JButton("Enviar");
        btnEnviar.setBounds(220, 10, 80, 30);
        getContentPane().add(btnEnviar);
        btnEnviar.addActionListener(
                new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Segunda v2 = new Segunda(estaVentana);
                        setVisible(false);

                    }

                });

        pack();
        repaint();

    }

    public static void main(String[] args) {
        Inicio v1 = new Inicio();
    }

}
